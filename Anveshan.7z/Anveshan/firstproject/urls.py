from . import views 
from django.urls import path  # type: ignore

urlpatterns = [
         path("", views.index, name="index2"),
         path("login2.html", views.login, name="login2"),
         path("home2.html", views.home, name="home2"),
         path("profile.html", views.profile, name="profile"),

]